import React from 'react'

export default function Footer() {
  return (
    <>
      <footer>
        <p className="text-center">
            Fooddeliverywebsite-2024-25.All Rights Reserved by Ashutosh
        </p>
      </footer>
    </>
  )
}
